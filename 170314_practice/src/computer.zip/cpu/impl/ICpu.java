package computer.cpu.impl;

public interface ICpu {

	void use();

	void unUse();

}
