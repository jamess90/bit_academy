package computer.ram;

public interface IRam {

	void wakeUp();

	void sleepIn();

}