package computer.drive;

public interface IDrive {
	void swapIn();

	void swapout();
}
